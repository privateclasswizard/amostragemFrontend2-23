import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { Link } from 'react-router-dom';
import'../../assets/css/Header.css'


function Header() {
  return (
    <Navbar expand="lg" className="bg-body-tertiary">
      <Container>
        <Link to="/"><Navbar.Brand href="#home">ENSALAMENTO</Navbar.Brand></Link>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <NavDropdown title="Formularios" id="basic-nav-dropdown">
            <Link to='/FormCurso'><NavDropdown.Item href="#action/3.1">Formulario curso</NavDropdown.Item></Link>
              <NavDropdown.Item href="#action/3.2">Formulario curso</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3"> Formulario periodo </NavDropdown.Item>
              <NavDropdown.Item href="#action/3.4">Formulario professor</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.5">Formulario sala</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.6">Formulario horario</NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Header;