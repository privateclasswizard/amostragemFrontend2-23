import React from "react";
import Header from "../../component/header/Header";


function Home() {
    return (
        <div>
            <Header/>
        </div>
    );
}

export default Home;