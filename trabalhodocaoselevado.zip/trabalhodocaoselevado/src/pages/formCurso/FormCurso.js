import React from "react";
import Header from "../../component/header/Header";


function FormCurso() {

    return (
        <div>
            <Header/>
            
        </div>
    );
}

export default FormCurso;