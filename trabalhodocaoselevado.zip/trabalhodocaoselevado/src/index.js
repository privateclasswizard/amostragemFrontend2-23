import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
// import App from './App';
import reportWebVitals from './reportWebVitals';

import {createBrowserRouter, RouterProvider} from 'react-router-dom'

import Home from './pages/home/Home.js';
import FormCurso from './pages/formCurso/FormCurso.js';

const router = createBrowserRouter([
  {path:"/", element:<Home />},
  {path:"/FormCurso", element:<FormCurso/>}
  // {path:"/FormProfessor", element:<FormProfessor/>},
  // {path:"/FormPeriodo", element:<FormPeriodo/>},
  // {path:"/FormSala", element:<FormSala/>},
  // {path:"/FormMateria", element:<FormMateria/>},
])


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {/* <App /> */}
    <RouterProvider router={router}/>
  </React.StrictMode>
);

reportWebVitals();
